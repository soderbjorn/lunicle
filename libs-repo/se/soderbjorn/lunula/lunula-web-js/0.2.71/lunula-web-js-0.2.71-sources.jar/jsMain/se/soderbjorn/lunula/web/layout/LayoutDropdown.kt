/**
 * Public, keyboard-navigable layout-preset dropdown shared by every
 * Lunula app's topbar.
 *
 * The dropdown is owned by the toolkit so notegrow and termtastic
 * present the same control with the same affordances. Apps construct
 * a [LayoutDropdown], append [triggerButton] to their topbar, and
 * supply two callbacks: [paneCount] (read each time the popover
 * opens) and [onSelect] (fired with the user's pick). The host
 * typically routes [onSelect] into a [LayoutController.setPreset].
 *
 * Affordances:
 * - Hover the trigger and the grid reveals itself; leaving it without
 *   landing in the grid puts it away again. The same contract the topbar's
 *   "+" menu has — see [se.soderbjorn.lunula.web.shell.attachHoverMenu] —
 *   down to the shared show/hide delays, because two buttons sitting side
 *   by side in one chrome should not disagree about what a hover means.
 * - Click the trigger to open / close — and nothing more. Where the "+"
 *   commits a default action on click and offers the menu as the way to
 *   ask for something else, this button has no default: there is no
 *   layout it could sensibly pick on your behalf, so the click is purely
 *   show/hide.
 * - Click a tile to pick.
 * - Arrow keys navigate the grid; mouse-move tracks focus too.
 * - Enter / Space invoke the focused tile.
 * - Escape closes.
 * - Outside click dismisses.
 *
 * A hover-revealed grid deliberately does *less* than a clicked one: it
 * takes no keyboard focus and answers no key but Escape, because moving a
 * cursor past a toolbar button is not a request to stop typing into
 * whatever had focus. It picks up the full keyboard behaviour the moment
 * the pointer actually enters the grid — see [openAnchoredTo]'s `takeFocus`.
 *
 * The self-closing is likewise the hover path's alone: a grid the user
 * opened by clicking stays up until they pick, press Escape, or click
 * away, even if the pointer wanders off in the meantime.
 *
 * Tiles render miniature SVG previews of each preset's geometry for
 * the current pane count via [LayoutPreset.computeBoxes]. The
 * preview viewBox and class names match the toolkit's bundled CSS
 * (`.dt-layout-preset-*`, `.dt-layout-preview-*`) so the dropdown
 * looks identical across apps without per-app styling.
 *
 * A miniature is drawn at most once. Presets that arrange the panes
 * identically at the current count — and there are always some, because
 * the catalogue is written for the general case — would otherwise give
 * the user several tiles carrying the same picture and the same result,
 * which is a choice that isn't one. The first of each such group in
 * [presets] keeps the tile and the rest are skipped.
 *
 * [LayoutPreset.Auto] is exempt from that, in both directions: it never
 * claims a picture and is never skipped for one. Auto is a *mode* rather
 * than a geometry — it is the only preset that re-tiles as panes come and
 * go, and the only one that hides the drag separators — so its boxes
 * coinciding with another preset's at some count is a coincidence of
 * shape and not evidence that the two offer the same thing. `Grid` from
 * six panes up is exactly that case: same picture as Auto, but a static
 * grid that keeps its separators and stays put when a pane spawns. The
 * exemption is also what makes the Auto tile a guarantee of this class
 * rather than of the order of [presets] — a caller whose list does not
 * lead with Auto still gets it, and so still gets the active marker and
 * the toggle-off click that go with it.
 *
 * The de-duplication is done per open rather than per instance, because
 * it depends entirely on a pane count that changes underneath the
 * dropdown: 32 tiles from three panes up, and two at one pane — Auto,
 * plus the single full-bleed box that every layout in the catalogue
 * really does collapse to there.
 *
 * @see LayoutPreset
 * @see LayoutPreset.DROPDOWN_ORDER
 * @see LayoutController.setPreset
 */
package se.soderbjorn.lunula.web.layout

import kotlinx.browser.document
import kotlinx.browser.window
import org.w3c.dom.HTMLElement
import org.w3c.dom.events.Event
import org.w3c.dom.events.KeyboardEvent
import org.w3c.dom.events.MouseEvent
import se.soderbjorn.lunula.web.shell.HOVER_MENU_HIDE_DELAY_MS
import se.soderbjorn.lunula.web.shell.HOVER_MENU_SHOW_DELAY_MS
import se.soderbjorn.lunula.web.shell.ICON_LAYOUT
import se.soderbjorn.lunula.web.shell.armHoverOpenSuppression
import se.soderbjorn.lunula.web.shell.isHoverOpenSuppressed

/**
 * One layout dropdown for an app's topbar. The dropdown owns its own
 * trigger button so callers don't have to wire open/close — they just
 * append [triggerButton] to the topbar.
 *
 * @param paneCount Re-evaluated each time the popover opens so the
 *   miniature tiles render with the current pane count of the active
 *   tab.
 * @param onSelect Fired with the picked preset; the host applies it
 *   (typically by calling [LayoutController.setPreset] and re-rendering).
 *   When the user clicks the tile that is already the active preset the
 *   dropdown fires [onSelect] with [LayoutPreset.Custom] — i.e. it
 *   toggles the preset off and returns the tab to "no preset driving"
 *   (geometry frozen wherever it last was).
 * @param activePreset Re-evaluated each time the popover opens to
 *   decide which tile, if any, gets the `is-active` accent. Return
 *   `null` (or [LayoutPreset.Custom]) when no preset is currently
 *   driving the tab. Default returns `null`.
 * @param presets The presets this dropdown may offer, in display order.
 *   Defaults to [LayoutPreset.DROPDOWN_ORDER] which starts with
 *   [LayoutPreset.Auto] and excludes [LayoutPreset.Custom] (a sentinel
 *   mode, not a target). This is the *candidate* list rather than the
 *   rendered one — membership and order are honoured exactly, but an
 *   entry whose miniature repeats an earlier one at the current pane
 *   count is skipped, so a caller that passes its own list still never
 *   shows the same tile twice. [LayoutPreset.Auto] is the one entry
 *   guaranteed to survive wherever it sits in the list: it draws a wand
 *   glyph rather than a miniature and takes no part in the skipping, so
 *   a caller is free to order it — or omit it — deliberately, and does
 *   not have to lead with it to keep it.
 */
class LayoutDropdown(
    private val paneCount: () -> Int,
    private val onSelect: (LayoutPreset) -> Unit,
    private val activePreset: () -> LayoutPreset? = { null },
    private val presets: List<LayoutPreset> = LayoutPreset.DROPDOWN_ORDER,
) {

    /** The toolbar trigger element. Stable across opens so callers can
     *  re-anchor popovers to the same element (e.g. a command-palette
     *  command "Layout" can call [openAnchoredTo] with [triggerButton]). */
    val triggerButton: HTMLElement by lazy { buildTrigger() }

    private var gridEl: HTMLElement? = null
    private var tiles: List<HTMLElement> = emptyList()

    /**
     * The presets the current open actually drew a tile for, index-parallel
     * to [tiles].
     *
     * Shorter than [presets] whenever two of them would have drawn the same
     * miniature at this pane count, so the keyboard activation path must
     * index into this and not into [presets] — otherwise Enter on the tile
     * under the ring would apply whichever preset happened to sit at that
     * position in the unfiltered catalogue.
     */
    private var visiblePresets: List<LayoutPreset> = emptyList()

    private var focusedIndex: Int = 0
    /** Active preset captured at the moment the popover opened. Drives
     *  both the `is-active` tile marker and the click-to-toggle-off
     *  decision; null when no preset is currently driving the tab. */
    private var activeAtOpen: LayoutPreset? = null

    private var documentClickHandler: ((Event) -> Unit)? = null
    private var documentKeyHandler: ((Event) -> Unit)? = null

    /** Pending hover-open timer; see [scheduleHoverOpen]. */
    private var showTimerId: Int? = null

    /** Pending hover-close timer; see [scheduleHoverClose]. */
    private var hideTimerId: Int? = null

    /**
     * Whether this open is allowed to drive the keyboard — set by
     * [openAnchoredTo]'s `takeFocus`, and raised later if a hover-revealed
     * grid is entered by the pointer.
     *
     * While `false` the grid is a passive preview: no tile wears the focus
     * ring, none is focused, and the document key handler answers Escape
     * only. Arrow keys and Enter belong to whatever the user was actually
     * typing into, which a hover never asked them to leave.
     */
    private var keyboardActive: Boolean = false

    /**
     * Whether this open was the hover reveal rather than something the user
     * asked for outright.
     *
     * Only a hover-revealed grid closes itself when the pointer leaves. A
     * grid opened by clicking the trigger — or by a command palette entry,
     * where the pointer may be nowhere near it — was asked for, and keeps
     * the dismissal rules it always had: pick a tile, press Escape, or
     * click away. Losing it because the mouse drifted while its owner
     * reached for the arrow keys would be taking something back that the
     * user explicitly asked for.
     */
    private var openedByHover: Boolean = false

    /** `true` while the popover is mounted. Used by the trigger's click
     *  handler to toggle. */
    fun isOpen(): Boolean = gridEl != null

    /**
     * Open the popover anchored under [anchor]. Idempotent — calling
     * while already open re-anchors and re-focuses.
     *
     * By default the first tile is focused so arrow keys are immediately
     * useful; pass `takeFocus = false` for an open the user did not ask
     * for outright, which comes up as a passive preview instead.
     *
     * Called by the trigger's own click handler, by the hover reveal
     * ([scheduleHoverOpen], with `takeFocus = false`), and by hosts that
     * raise the grid from elsewhere — e.g. a command-palette "Layout"
     * entry anchoring to [triggerButton].
     *
     * @param anchor the element the grid is positioned under; its
     *   bottom-right corner is where the grid hangs from.
     * @param takeFocus whether this open may claim the keyboard: focus the
     *   first tile, paint the focus ring, and answer arrow keys / Enter.
     *   `true` for the deliberate opens (a click on the trigger, a command
     *   palette entry), where the user has asked for the grid and expects
     *   to drive it. Passed `false` by the hover reveal, which happens
     *   without being asked for and so must not pull focus out of a
     *   terminal the user is mid-sentence in; the grid still lists and
     *   still clicks, and promotes itself the moment the pointer enters it.
     */
    fun openAnchoredTo(anchor: HTMLElement, takeFocus: Boolean = true) {
        if (gridEl != null) close()
        // Only one grid at a time, including one this instance doesn't own.
        // The topbar is rebuilt wholesale on re-render, which builds a fresh
        // LayoutDropdown and quietly detaches the old trigger — without
        // firing the `mouseleave` that would have closed its grid. That
        // orphan can no longer close itself, so the next open evicts it,
        // the same way the hover menu evicts stale `.dt-hover-menu` nodes.
        val stale = document.querySelectorAll(".dt-layout-preset-grid")
        for (i in 0 until stale.length) (stale.item(i) as HTMLElement).remove()
        keyboardActive = takeFocus
        openedByHover = false
        val n = paneCount()
        val grid = document.createElement("div") as HTMLElement
        grid.className = "dt-layout-preset-grid"
        // Outline the focus ring on the focused tile so keyboard users can
        // see where they are without us having to manage focus outlines
        // manually.
        grid.tabIndex = -1

        // Snapshot the active preset for this open so click handlers
        // and the keyboard activation path see the same value the tile
        // marker was painted with — avoids a stale-decision footgun if
        // the active preset changed between open and click.
        //
        // Only Auto is treated as "active". Every other preset is a
        // one-shot that applies geometry once and then doesn't enforce
        // anything further, so marking it active in the dropdown would
        // mislead users into thinking the layout is still being held.
        activeAtOpen = activePreset()?.takeIf { it == LayoutPreset.Auto }

        // Miniatures already drawn by this open. A preset whose miniature
        // repeats one above it is skipped: it would arrange the panes the
        // same way, so a second tile carrying the same picture is a
        // choice that isn't one. That is very literally the bug LNA-13
        // reported — at a single pane every preset in the catalogue is one
        // full-bleed box, so the grid came up as 32 copies of the same
        // rectangle.
        //
        // Auto takes no part in this — see the exemption in the loop
        // below — so this set holds geometry tiles only.
        //
        // Rebuilt on every open rather than cached, because the pane count
        // is read fresh above and decides the whole thing: at one pane the
        // 31 geometry presets are one box between them, at four they are
        // 31 distinct pictures, and shapes merge and separate again at
        // every count in between as panes open and close.
        val drawn = LinkedHashSet<String>()
        val shown = mutableListOf<LayoutPreset>()

        val tileList = mutableListOf<HTMLElement>()
        if (n <= 0) {
            val empty = document.createElement("div") as HTMLElement
            empty.className = "dt-layout-preset-empty"
            empty.textContent = "No panes in this tab"
            grid.appendChild(empty)
        } else {
            for (preset in presets) {
                // Auto is exempt from the whole de-duplication, in both
                // directions: it neither claims a key nor is skipped by
                // one. Auto is a *mode*, not a geometry — it is the only
                // preset that re-tiles when panes are added or removed
                // (see AppShellMount's `presetIsAuto`) and the only one
                // that hides the drag separators (see PaneSeparators) —
                // so the fact that its boxes coincide with some other
                // preset's at a given count says nothing about whether
                // the two offer the same thing. Grid at six panes is the
                // case that matters: it draws what Auto draws, but it is
                // a *static* grid that keeps its separators and does not
                // re-tile, so suppressing it would make a genuinely
                // different option unreachable from six panes up.
                //
                // Exempting it in the other direction too is what keeps
                // Auto's tile a property of this code rather than of
                // DROPDOWN_ORDER's ordering: a caller passing a `presets`
                // list that does not lead with Auto still gets the Auto
                // tile, and so still gets the `is-active` marker and the
                // toggle-off click that `activeAtOpen` depends on.
                //
                // Auto also never draws a miniature — its tile paints
                // AUTO_TILE_GLYPH — so there is nothing of its to compare
                // in the first place.
                val isAuto = preset == LayoutPreset.Auto
                // The miniature is both what the tile shows and what
                // decides whether the tile is drawn at all, so identical
                // markup means identical rendering by construction — no
                // separate notion of "same layout" to keep in step, and no
                // float tolerance to pick. That invariant holds only for
                // the presets that actually draw one, which is why Auto
                // sits outside it.
                val miniature = if (isAuto) {
                    null
                } else {
                    renderPresetMiniatureSvg(
                        preset.computeBoxes(n),
                        preset.emphasizedSlotCount,
                    )
                }
                if (miniature != null && !drawn.add(miniature)) continue
                shown += preset

                val tile = document.createElement("button") as HTMLElement
                tile.setAttribute("type", "button")
                tile.className = "dt-layout-preset-tile"
                if (isAuto) tile.classList.add("dt-layout-preset-tile-auto")
                if (preset == activeAtOpen) {
                    tile.classList.add("is-active")
                    // aria-pressed lets screen readers announce the
                    // toggle state — clicking again will turn the
                    // preset off (return to Custom).
                    tile.setAttribute("aria-pressed", "true")
                }
                tile.title = preset.label
                tile.setAttribute("aria-label", preset.label)
                // Auto gets a distinctive magic-wand glyph so it can't be
                // confused with the geometry-preview tiles around it.
                // Other presets render their per-pane-count miniature.
                tile.innerHTML = miniature ?: AUTO_TILE_GLYPH
                tile.addEventListener("click", { e: Event ->
                    e.stopPropagation()
                    selectOrToggleAndClose(preset, activeAtOpen)
                })
                tile.addEventListener("mousemove", { _: Event ->
                    val idx = tileList.indexOf(tile)
                    // The pointer is on a tile: whatever revealed the grid,
                    // the user is now working it, so a hover-opened grid
                    // stops being a passive preview and starts tracking
                    // focus like a clicked one.
                    val promoting = !keyboardActive
                    keyboardActive = true
                    if (idx >= 0 && (idx != focusedIndex || promoting)) {
                        focusedIndex = idx
                        repaintFocusRing()
                    }
                })
                grid.appendChild(tile)
                tileList += tile
            }
            if (n == 1) {
                // One pane is one full-bleed box whichever geometry you
                // pick, so exactly one geometry tile survives the skip —
                // and Auto's wand sits beside it, two tiles in all. That
                // is the honest answer, but two tiles in an otherwise
                // empty popover read as a rendering fault rather than as
                // a statement, so say out loud why there is nothing else
                // here. Auto stays offered because it is a mode rather
                // than a shape: arming it before splitting the pane is a
                // reasonable thing to want at one pane, and it is the one
                // thing on offer here that will still be doing something
                // at the second pane.
                val note = document.createElement("div") as HTMLElement
                note.className = "dt-layout-preset-note"
                note.textContent = ONE_PANE_LAYOUT_NOTE
                grid.appendChild(note)
            }
        }
        visiblePresets = shown

        document.body?.appendChild(grid)
        gridEl = grid
        tiles = tileList

        positionGrid(grid, anchor)
        focusedIndex = 0
        repaintFocusRing()

        // The grid is the other half of the hover surface: crossing the gap
        // from the trigger into it must call off the pending close, and
        // leaving it must start one — otherwise a menu you hovered open
        // could only be dismissed by clicking.
        grid.addEventListener("mouseenter", { _: Event -> cancelHoverClose() })
        grid.addEventListener("mouseleave", { _: Event ->
            if (openedByHover) scheduleHoverClose()
        })

        attachDocumentDismiss(anchor)
    }

    /** Close the popover. Idempotent. */
    fun close() {
        cancelHoverOpen()
        cancelHoverClose()
        gridEl?.let { it.parentNode?.removeChild(it) }
        gridEl = null
        tiles = emptyList()
        visiblePresets = emptyList()
        focusedIndex = 0
        activeAtOpen = null
        keyboardActive = false
        openedByHover = false
        detachDocumentDismiss()
    }

    /**
     * Reveal the grid after [HOVER_MENU_SHOW_DELAY_MS], unless something
     * cancels first. Called from the trigger's `mouseenter`.
     *
     * The delay is what keeps a cursor merely passing over the topbar from
     * flinging the grid open behind it.
     *
     * @param anchor the element to hang the grid under when the timer
     *   fires — always [triggerButton] in practice, passed rather than read
     *   so the timer cannot resolve it differently than the hover did.
     * @see cancelHoverOpen
     */
    private fun scheduleHoverOpen(anchor: HTMLElement) {
        cancelHoverOpen()
        showTimerId = window.setTimeout(
            {
                openAnchoredTo(anchor, takeFocus = false)
                // Set after the open, which clears it: this is the one
                // path that may close itself again on `mouseleave`.
                openedByHover = true
            },
            HOVER_MENU_SHOW_DELAY_MS,
        )
    }

    /** Drops any pending hover-open. Idempotent. */
    private fun cancelHoverOpen() {
        showTimerId?.let { window.clearTimeout(it) }
        showTimerId = null
    }

    /**
     * Close the grid after [HOVER_MENU_HIDE_DELAY_MS]. Called when the
     * pointer leaves either half of the hover surface; entering the other
     * half within the grace period calls it off, which is what makes the
     * diagonal from trigger to grid survivable.
     */
    private fun scheduleHoverClose() {
        cancelHoverClose()
        hideTimerId = window.setTimeout({ close() }, HOVER_MENU_HIDE_DELAY_MS)
    }

    /** Drops any pending hover-close. Idempotent. */
    private fun cancelHoverClose() {
        hideTimerId?.let { window.clearTimeout(it) }
        hideTimerId = null
    }

    /**
     * Builds the topbar icon button behind [triggerButton], wired for both
     * gestures: hover reveals the grid and leaving puts it away, click
     * toggles it.
     *
     * Called once, lazily, the first time a host reads [triggerButton].
     *
     * @return the trigger element, not yet mounted; the host appends it.
     * @see se.soderbjorn.lunula.web.shell.attachHoverMenu the "+" button's
     *   equivalent, whose hover contract and delays this matches.
     */
    private fun buildTrigger(): HTMLElement {
        val btn = document.createElement("button") as HTMLElement
        btn.setAttribute("type", "button")
        btn.title = "Layout"
        btn.className = "dt-topbar-icon-button"
        btn.innerHTML = ICON_LAYOUT
        btn.addEventListener("click", { _: Event ->
            cancelHoverOpen()
            // Open or close, and nothing else. Unlike the "+" next to it,
            // this button has no default action to commit — there is no
            // "the layout you probably meant", so a click that quietly
            // applied one would be picking for the user. The grid is the
            // whole offer, and the click is only how you ask for it or
            // take the question back.
            if (isOpen()) close() else openAnchoredTo(btn)
            // Whichever way that went, the user has just decided something
            // with a click, and the cursor is now parked on the button.
            // Without this the next `mouseenter` — which the browser fires
            // again the instant a topbar rebuild swaps in a fresh trigger
            // element under the unmoved pointer — would re-open the grid
            // they just dismissed. Shared with the "+" menu so a click on
            // either button silences hover for both.
            armHoverOpenSuppression(btn)
        })
        btn.addEventListener("mouseenter", { ev: Event ->
            // Arriving back on the trigger while a close is pending means
            // the user never really left.
            cancelHoverClose()
            if (isOpen()) return@addEventListener
            if (isHoverOpenSuppressed(ev)) return@addEventListener
            scheduleHoverOpen(btn)
        })
        btn.addEventListener("mouseleave", { ev: Event ->
            cancelHoverOpen()
            // Heading straight into the grid is not leaving; the grid's own
            // `mouseenter` would cancel the close anyway, but skipping the
            // timer entirely avoids a needless close/cancel round-trip.
            val related = (ev as? MouseEvent)?.relatedTarget as? HTMLElement
            if (related != null && gridEl?.contains(related) == true) return@addEventListener
            if (isOpen() && openedByHover) scheduleHoverClose()
        })
        return btn
    }

    private fun positionGrid(grid: HTMLElement, anchor: HTMLElement) {
        val rect = anchor.getBoundingClientRect()
        val gridRect = grid.getBoundingClientRect()
        val left = (rect.right - gridRect.width).coerceAtLeast(4.0)
        grid.style.left = "${left}px"
        grid.style.top = "${rect.bottom + 4}px"
    }

    private fun repaintFocusRing() {
        // A hover-revealed grid shows no focus ring and steals no focus:
        // there is no "where you are" to paint until the user has said,
        // by pointing at it or by opening it on purpose, that they are in
        // the grid at all.
        if (!keyboardActive) {
            for (tile in tiles) tile.classList.toggle("is-focused", false)
            return
        }
        for ((i, tile) in tiles.withIndex()) {
            val focused = i == focusedIndex
            // Toggle only the is-focused class — overwriting className
            // would strip the per-tile state classes
            // (`dt-layout-preset-tile-auto`, `is-active`).
            tile.classList.toggle("is-focused", focused)
            if (focused) {
                tile.focus()
                tile.scrollIntoView(js("({block:'nearest'})"))
            }
        }
    }

    /**
     * Closes the popover and fires [onSelect]. When [preset] equals
     * [activeAtOpen] the user is clicking the already-active tile —
     * fire [onSelect] with [LayoutPreset.Custom] instead so the host
     * toggles the preset off (geometry frozen wherever it last landed)
     * rather than re-applying the same layout. In practice this only
     * triggers for Auto, since one-shot presets aren't tracked as
     * active and so will never compare equal to [activeAtOpen].
     */
    private fun selectOrToggleAndClose(preset: LayoutPreset, activeAtOpen: LayoutPreset?) {
        val toFire = if (preset == activeAtOpen) LayoutPreset.Custom else preset
        close()
        onSelect(toFire)
    }

    private fun attachDocumentDismiss(anchor: HTMLElement) {
        // Capture phase + mousedown so a click landing anywhere outside the
        // popover dismisses *before* the target's own handler can call
        // `stopPropagation()`. The previous bubble-phase listener missed
        // dismissals when other top-bar buttons (sidebar toggle, theme
        // picker, …) stopped propagation in their own handlers, leaving
        // the popover stuck open while the user clearly meant to dismiss.
        val clickHandler: (Event) -> Unit = handler@{ e ->
            val target = e.target as? HTMLElement ?: return@handler
            val grid = gridEl ?: return@handler
            if (grid.contains(target)) return@handler
            if (anchor.contains(target)) return@handler
            close()
        }
        val keyHandler: (Event) -> Unit = handler@{ e ->
            val ke = e as? KeyboardEvent ?: return@handler
            // Escape always closes — dismissing something that appeared
            // uninvited is exactly what Escape is for. Every other key
            // belongs to whatever holds focus until the user engages with
            // the grid; a listener in the capture phase that ate arrow keys
            // because the cursor happened to rest on the layout button
            // would be stealing them from a terminal.
            if (ke.key != "Escape" && !keyboardActive) return@handler
            when (ke.key) {
                "Escape" -> {
                    ke.preventDefault()
                    close()
                }
                "ArrowRight" -> {
                    if (tiles.isNotEmpty()) {
                        ke.preventDefault()
                        focusedIndex = (focusedIndex + 1).coerceAtMost(tiles.lastIndex)
                        repaintFocusRing()
                    }
                }
                "ArrowLeft" -> {
                    if (tiles.isNotEmpty()) {
                        ke.preventDefault()
                        focusedIndex = (focusedIndex - 1).coerceAtLeast(0)
                        repaintFocusRing()
                    }
                }
                "ArrowDown" -> {
                    if (tiles.isNotEmpty()) {
                        ke.preventDefault()
                        focusedIndex = (focusedIndex + GRID_COLUMNS).coerceAtMost(tiles.lastIndex)
                        repaintFocusRing()
                    }
                }
                "ArrowUp" -> {
                    if (tiles.isNotEmpty()) {
                        ke.preventDefault()
                        focusedIndex = (focusedIndex - GRID_COLUMNS).coerceAtLeast(0)
                        repaintFocusRing()
                    }
                }
                "Enter", " " -> {
                    if (tiles.isEmpty()) return@handler
                    // Indexes the rendered list, not the candidate list —
                    // they differ whenever the pane count collapsed a
                    // duplicate group away.
                    val preset = visiblePresets.getOrNull(focusedIndex) ?: return@handler
                    ke.preventDefault()
                    selectOrToggleAndClose(preset, activeAtOpen)
                }
            }
        }
        documentClickHandler = clickHandler
        documentKeyHandler = keyHandler
        // Capture phase for both. Listening to `mousedown` (instead of
        // `click`) means we run before any sibling handler can call
        // `stopPropagation()`, so clicks on other top-bar buttons (sidebar
        // toggle, theme picker, …) reliably dismiss the popover. The
        // tile's own click handler still fires after dismissal — but at
        // that point we've already closed and `selectOrToggleAndClose`'s
        // close() is a no-op, so there's no double-close risk.
        document.addEventListener("mousedown", clickHandler, /* capture = */ true)
        document.addEventListener("keydown", keyHandler, /* capture = */ true)
    }

    private fun detachDocumentDismiss() {
        documentClickHandler?.let {
            document.removeEventListener("mousedown", it, /* capture = */ true)
        }
        documentKeyHandler?.let {
            document.removeEventListener("keydown", it, /* capture = */ true)
        }
        documentClickHandler = null
        documentKeyHandler = null
    }

    companion object {
        /** Matches the toolkit's `.dt-layout-preset-grid`'s 3-column grid. */
        private const val GRID_COLUMNS = 3
    }
}

/**
 * Magic-wand + sparkles glyph painted on the `Auto` tile in place of a
 * geometry miniature. Drawn with the same stroke weight and viewBox as
 * the trigger icon so the dropdown reads as a single visual family. The
 * wand says "the toolkit picks for you" without committing to a specific
 * tiling shape.
 *
 * That distinction is not decoration. `Auto` is the only preset that
 * re-tiles when panes are added or removed and the only one that hides
 * the drag separators, so it is a mode rather than a shape — and drawing
 * it as one of the shapes invites the reading that picking it is picking
 * a tiling. It is also what lets `Auto` sit outside the dropdowns'
 * de-duplication without putting two identical pictures on screen: the
 * wand can never repeat a miniature.
 *
 * Shared by both of the toolkit's preset grids — [LayoutDropdown] and
 * the topbar's older
 * [se.soderbjorn.lunula.web.shell.buildLayoutPresetButton] — so `Auto`
 * reads the same wherever it is offered. `internal` for that reason
 * alone; consumers have no business painting toolkit tiles themselves.
 *
 * @see LayoutDropdown.openAnchoredTo
 */
internal const val AUTO_TILE_GLYPH: String =
    "<svg viewBox=\"0 0 36 24\" width=\"36\" height=\"24\" " +
        "class=\"dt-layout-preview dt-layout-preview-auto\" aria-hidden=\"true\">" +
        // Wand body, lower-left to upper-right
        "<line x1=\"6\" y1=\"19\" x2=\"22\" y2=\"7\" stroke=\"currentColor\" " +
        "stroke-width=\"1.6\" stroke-linecap=\"round\"/>" +
        // Wand tip diamond (filled with primary accent)
        "<path d=\"M22 5 L25 8 L22 11 L19 8 Z\" class=\"dt-layout-preview-primary\"/>" +
        // Sparkle 1: small star top-right
        "<path d=\"M30 4 L31 6 L33 7 L31 8 L30 10 L29 8 L27 7 L29 6 Z\" " +
        "class=\"dt-layout-preview-primary\"/>" +
        // Sparkle 2: tiny star middle-right
        "<path d=\"M28 14 L28.6 15.2 L29.8 15.8 L28.6 16.4 L28 17.6 L27.4 16.4 " +
        "L26.2 15.8 L27.4 15.2 Z\" class=\"dt-layout-preview-other\"/>" +
        "</svg>"

/**
 * Footer line rendered under the two-tile grid at one pane, where every
 * geometry preset in the catalogue draws the same full-bleed box and so
 * exactly one of them survives the duplicate skip — leaving that box and
 * the `Auto` wand, which never takes part in the skip.
 *
 * Explains the short grid rather than leaving it looking like a
 * half-drawn popover, and says what `Auto` will do once there is more
 * than one pane to arrange. Shared with the topbar's older preset grid
 * ([se.soderbjorn.lunula.web.shell.buildLayoutPresetButton]) so the two
 * dropdowns say the same thing in the same situation.
 *
 * @see LayoutDropdown.openAnchoredTo
 * @see AUTO_TILE_GLYPH
 */
internal const val ONE_PANE_LAYOUT_NOTE: String =
    "One pane fills the tab, so every layout looks the same. " +
        "Auto keeps tiling as you add panes."

/**
 * Renders a tile-sized SVG miniature for [boxes]. Mirrors the
 * toolkit's CSS rules `.dt-layout-preview`,
 * `.dt-layout-preview-primary`, `.dt-layout-preview-secondary`,
 * `.dt-layout-preview-other` so every tile in every app picks up the
 * same colours.
 *
 * @param boxes geometry to draw, slot 0 first.
 * @param emphasized how many leading slots get a "ranked" fill — slot
 *   0 always gets `-primary`, slots `1..emphasized-1` get `-secondary`
 *   (translucent accent), and the rest get `-other` (grey filler).
 *   Pass `LayoutPreset.emphasizedSlotCount`. Defaults to `1` so callers
 *   without rank metadata fall back to the single-primary behaviour.
 */
private fun renderPresetMiniatureSvg(boxes: List<LayoutBox>, emphasized: Int = 1): String {
    val w = 36
    val h = 24
    val pad = 1.0
    val sb = StringBuilder()
    sb.append(
        "<svg viewBox=\"0 0 $w $h\" width=\"$w\" height=\"$h\" " +
            "class=\"dt-layout-preview\" aria-hidden=\"true\">",
    )
    for ((i, b) in boxes.withIndex()) {
        val bx = b.x * w + pad
        val by = b.y * h + pad
        val bw = (b.width * w - pad * 2).coerceAtLeast(2.0)
        val bh = (b.height * h - pad * 2).coerceAtLeast(2.0)
        val cls = when {
            i == 0 -> "dt-layout-preview-primary"
            i < emphasized -> "dt-layout-preview-secondary"
            else -> "dt-layout-preview-other"
        }
        sb.append(
            "<rect x=\"$bx\" y=\"$by\" width=\"$bw\" height=\"$bh\" rx=\"1.2\" class=\"$cls\"/>",
        )
    }
    sb.append("</svg>")
    return sb.toString()
}
