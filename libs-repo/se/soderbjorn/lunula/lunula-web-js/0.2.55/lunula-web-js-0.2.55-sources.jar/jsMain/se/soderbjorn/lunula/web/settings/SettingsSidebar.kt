/**
 * Settings sidebar — slide-in right-side panel exposing every per-app
 * appearance / window control the toolkit owns.
 *
 * Sections rendered (in order):
 *  1. Custom title bar On/Off (Electron only).
 *  2. Corner roundness + Selection + Spacing — the shell's shape, its
 *     selection language, and its density.
 *  3. Sidebar font face + size pill rows.
 *  4. Tab bar font face + size pill rows.
 *  5. Window title font face + size pill rows.
 *  6. Monospaced (main-content) font face + size pill rows.
 *  7. Proportional (main-content) font face + size pill rows.
 *  8. Display (main-content headings) font face + size pill rows.
 *
 * Shape before type, deliberately: roundness and spacing change what the
 * shell IS shaped like, where every font row changes what it is lettered in.
 *
 * Note what is NOT here: colour. Corner roundness and spacing are user
 * preferences that must survive a theme change — a user who likes square
 * corners should not have to give up a palette to keep them — so they live
 * beside the fonts and are persisted per-app, not stored on a [Theme].
 *
 * Mutual exclusion with the [ThemeManagerSidebar]: both occupy the
 * single right-sidebar slot owned by [mountAppShell]. The slot's
 * `rerender` path checks whichever of the two is open; toggling one open
 * while the other is open is implemented at the topbar-button level (see
 * the calls to [closeSettingsSidebar] / [closeThemeManagerSidebar] in
 * `AppShellMount.buildTopBar`).
 *
 * Public API mirrors `ThemeManagerSidebar` so apps wire it the same way:
 *   - [toggleSettingsSidebar] flips state and asks the host to rebuild.
 *   - [isSettingsSidebarOpen] is consulted by the host's rebuild path.
 *   - [buildSettingsSidebar] returns the freshly-mounted `<aside>` once
 *     the host's rebuild reaches the right-sidebar slot.
 *
 * @see SettingsSidebarSpec
 * @see ThemeManagerHost
 */
package se.soderbjorn.lunula.web.settings

import kotlinx.browser.document
import kotlinx.browser.window
import org.w3c.dom.HTMLElement
import org.w3c.dom.events.Event
import org.w3c.dom.events.KeyboardEvent
import se.soderbjorn.lunula.web.applyMonoFontFamily
import se.soderbjorn.lunula.web.applyMonoFontSizePx
import se.soderbjorn.lunula.web.applyProportionalFontFamily
import se.soderbjorn.lunula.web.applyProportionalFontSizePx
import se.soderbjorn.lunula.web.applySidebarFontFamily
import se.soderbjorn.lunula.web.applySidebarFontSizePx
import se.soderbjorn.lunula.web.applyTabbarFontFamily
import se.soderbjorn.lunula.web.applyTabbarFontSizePx
import se.soderbjorn.lunula.web.applyPaneHeaderFontFamily
import se.soderbjorn.lunula.web.applyPaneHeaderFontSizePx
import se.soderbjorn.lunula.web.applyDisplayFontFamily
import se.soderbjorn.lunula.web.applyDisplayFontSizePx
import se.soderbjorn.lunula.web.applyCornerRadiusPx
import se.soderbjorn.lunula.web.applyUiDensity
import se.soderbjorn.lunula.web.applySelectionStyle
import se.soderbjorn.lunula.core.AppearanceShape
import se.soderbjorn.lunula.core.SelectionStyle
import se.soderbjorn.lunula.core.UiDensity
import se.soderbjorn.lunula.web.shell.SidebarSpec
import se.soderbjorn.lunula.web.shell.renderRightSidebar
import se.soderbjorn.lunula.web.themeeditor.FontKind
import se.soderbjorn.lunula.web.themeeditor.ThemeManagerHost
import se.soderbjorn.lunula.web.themeeditor.detectInstalledFonts
import se.soderbjorn.lunula.web.themeeditor.allFontPresets

/**
 * Spec passed to [buildSettingsSidebar].
 *
 * @property host                  the toolkit-shared host that owns persisted
 *   per-app settings. Reads pull from [host]'s getters; writes call its
 *   setters.
 * @property isElectron            when `false`, the Custom title bar section
 *   is hidden (it requires Electron's `titleBarStyle: hiddenInset`).
 * @property onOpenThemeManager    invoked by the "Open theme manager" button
 *   inside section 1. Hosts typically call their existing theme-manager
 *   toggle; the SettingsSidebar deliberately does not own that flow.
 * @property mainSizePresets       size pill values for the Monospaced and
 *   Proportional sections.
 * @property sidebarSizePresets    size pill values for the Sidebar and
 *   Tab bar sections (chrome typically uses a tighter range).
 * @property sidebarSizeDefault    size to highlight in the Sidebar and Tab
 *   bar rows when the host getter returns null (i.e. the user has not
 *   explicitly picked one). 13 matches the toolkit chrome's CSS default
 *   (`.dt-app-frame { font-size: 13px }`).
 * @property mainSizeDefault       size to highlight in the Monospaced and
 *   Proportional rows when the host getter returns null. Apps whose main
 *   pane content uses a different intrinsic size may pass their own.
 */
data class SettingsSidebarSpec(
    val host: ThemeManagerHost,
    val isElectron: Boolean,
    val onOpenThemeManager: () -> Unit,
    val mainSizePresets: List<Int> = (10..24).toList(),
    val sidebarSizePresets: List<Int> = (10..18).toList(),
    val sidebarSizeDefault: Int = 13,
    val mainSizeDefault: Int = 14,
    /**
     * Effective font-preset key applied to the CHROME surfaces (sidebar / tab
     * bar / window title) when the user has picked none — i.e. a deployment
     * brand font, resolved the same way [se.soderbjorn.lunula.web.shell.AppShellSpec.defaultChromeFontFamily]
     * is. Returns null on an unbranded instance. The chrome font rows highlight
     * this pill (falling back to `systemProp`) when there is no explicit user
     * pick, so the ringed option matches the font actually painted rather than
     * misleadingly showing "System Default" while a brand font is on screen.
     */
    val chromeDefaultKey: () -> String? = { null },
    /** Effective proportional (prose) default key when the user picked none, or null. */
    val proseDefaultKey: () -> String? = { null },
    /** Effective display (heading) default key when the user picked none, or null. */
    val displayDefaultKey: () -> String? = { null },
    /**
     * Corner-radius pill values, in render order.
     *
     * A short, opinionated ladder rather than a range: 0 is square, 18 is the
     * toolkit default, and the steps between are the ones that read as
     * distinct at a glance. Offering every integer would present forty
     * choices to answer a question with about five real answers.
     */
    val cornerRadiusPresets: List<Int> = listOf(0, 4, 8, 12, 18, 24),
    /**
     * The shape settings the app applies when the user has picked none — a
     * deployment brand's defaults, resolved the same way [chromeDefaultKey] is.
     *
     * Each row highlights this value when the host's own is null, so the ringed
     * pill matches what is actually painted rather than claiming the toolkit
     * default while a branded instance shows something else. Fields left null
     * fall through to the toolkit's own defaults.
     */
    val appDefaultShape: () -> AppearanceShape = { AppearanceShape() },
)

/**
 * The radius the corner row highlights when the host has stored none.
 *
 * Must match `--dt-corner-radius`'s fallback in `lunula.css`, or the ringed
 * pill claims a value the shell is not actually painting.
 */
private const val DEFAULT_CORNER_RADIUS_PX: Int = 18

/** True while the Settings sidebar is considered open. */
private var sidebarOpen: Boolean = false

/** The currently-mounted sidebar element, or null when closed. */
private var currentSidebar: HTMLElement? = null

/** Last-known target width — used as the slide-in destination on next mount. */
private var lastWidthPx: Int = 420

/**
 * Latest `requestRebuild` callback handed to [toggleSettingsSidebar].
 *
 * Captured so the panel's own close affordances (X button, Escape) can
 * trigger the same animate-then-rebuild close path as the topbar toggle.
 */
private var lastRequestRebuild: (() -> Unit)? = null

/** Document-level Escape handler installed while the sidebar is open. */
private var escHandler: ((Event) -> Unit)? = null

/**
 * Whether the Settings sidebar is currently open. The host's rebuild
 * path consults this to decide whether to mount the sidebar.
 */
fun isSettingsSidebarOpen(): Boolean = sidebarOpen

/**
 * Toggle the Settings sidebar open/closed.
 *
 * On open: flips state to true, clears any stale element reference (so
 * the next mount runs the slide-in animation), and calls [requestRebuild]
 * so the host re-renders its AppFrame with the sidebar slot populated.
 *
 * On close: animates the existing sidebar element to width 0, waits for
 * `transitionend`, then flips state to false and calls [requestRebuild].
 */
fun toggleSettingsSidebar(requestRebuild: () -> Unit) {
    lastRequestRebuild = requestRebuild
    if (!sidebarOpen) {
        sidebarOpen = true
        currentSidebar = null
        requestRebuild()
        return
    }
    val sidebar = currentSidebar
    if (sidebar == null) {
        sidebarOpen = false
        requestRebuild()
        return
    }
    var done = false
    val handler: (Event) -> Unit = handler@{ ev ->
        if (done) return@handler
        if (ev.target !== sidebar) return@handler
        done = true
        sidebarOpen = false
        currentSidebar = null
        teardownEscHandler()
        requestRebuild()
    }
    sidebar.addEventListener("transitionend", handler)
    window.requestAnimationFrame { sidebar.style.width = "0px" }
}

/**
 * Force-close the Settings sidebar synchronously (no animation).
 *
 * Called by the topbar button that opens the Theme Manager so the two
 * right-side panels are mutually exclusive: the host calls this first,
 * then opens the manager. The settings element is detached on the next
 * `requestRebuild`.
 */
fun closeSettingsSidebar() {
    sidebarOpen = false
    currentSidebar = null
    teardownEscHandler()
}

private fun teardownEscHandler() {
    escHandler?.let { document.removeEventListener("keydown", it) }
    escHandler = null
}

/**
 * Build the right-sidebar `<aside>` element that hosts the Settings panel.
 *
 * Returned to the caller for them to pass into their
 * `AppFrameSpec(rightSidebar = …)` slot. Starts at `width: 0` and slides
 * to [SettingsSidebarSpec] (no public param yet for width since the
 * settings panel is fairly tall and a fixed 420 px reads well).
 *
 * @param spec the sidebar configuration.
 * @return the freshly-mounted sidebar element.
 */
fun buildSettingsSidebar(spec: SettingsSidebarSpec): HTMLElement {
    val resolvedWidthPx = lastWidthPx

    val mountTarget = document.createElement("div") as HTMLElement
    mountTarget.style.apply {
        width = "100%"
        flex = "1 1 auto"
        setProperty("min-height", "0")
        display = "flex"
        flexDirection = "column"
        // No `overflow-y: auto` here. The settings body manages its own
        // scroll on `.dt-settings-sidebar-sections` so the header stays
        // pinned. A second scroll container at the mount level would
        // absorb the overflow first and the inner section list would
        // never engage its own scrollbar — leaving the bottom rows
        // hidden below the panel.
    }

    val isReMount = currentSidebar != null

    val sidebar = renderRightSidebar(
        SidebarSpec(
            widthPx = resolvedWidthPx,
            content = mountTarget,
            visible = true,
            isResizable = false,
            minWidthPx = 360,
            maxWidthPx = 600,
        )
    )
    currentSidebar = sidebar

    if (isReMount) {
        sidebar.style.width = "${resolvedWidthPx}px"
        renderSettingsBody(mountTarget, spec)
    } else {
        // Double-rAF for the slide-in transition — see comment in
        // ThemeManagerSidebar.buildThemeManagerSidebar. Single rAF can
        // fire before the appended element ever paints at width:0, which
        // makes the browser skip the transition (visible when switching
        // between Theme Manager and Settings).
        sidebar.style.width = "0px"
        window.requestAnimationFrame {
            window.requestAnimationFrame {
                sidebar.style.width = "${resolvedWidthPx}px"
                renderSettingsBody(mountTarget, spec)
            }
        }
    }

    teardownEscHandler()
    val handler: (Event) -> Unit = { ev ->
        val key = (ev as? KeyboardEvent)?.key
        if (key == "Escape") {
            val rebuild = lastRequestRebuild
            if (rebuild != null) toggleSettingsSidebar(rebuild)
        }
    }
    document.addEventListener("keydown", handler)
    escHandler = handler

    return sidebar
}

/**
 * Mounts the Settings panel content into [target].
 *
 * Each section is built once per render; pill rows re-render in place
 * after a click so the selected state updates without rebuilding the
 * whole panel.
 */
private fun renderSettingsBody(target: HTMLElement, spec: SettingsSidebarSpec) {
    target.innerHTML = ""

    val panel = document.createElement("div") as HTMLElement
    panel.className = "dt-settings-sidebar-body"

    val header = document.createElement("div") as HTMLElement
    header.className = "dt-settings-sidebar-header"

    val title = document.createElement("h2") as HTMLElement
    title.className = "dt-settings-sidebar-title"
    title.textContent = "Appearance"
    header.appendChild(title)

    val closeBtn = document.createElement("button") as HTMLElement
    closeBtn.className = "dt-settings-sidebar-close"
    closeBtn.setAttribute("type", "button")
    closeBtn.innerHTML = "&times;"
    closeBtn.title = "Close"
    closeBtn.addEventListener("click", {
        val rebuild = lastRequestRebuild
        if (rebuild != null) toggleSettingsSidebar(rebuild)
    })
    header.appendChild(closeBtn)

    panel.appendChild(header)

    val body = document.createElement("div") as HTMLElement
    body.className = "dt-settings-sidebar-sections"
    panel.appendChild(body)

    // The Theme Manager already has a dedicated topbar entry (the
    // palette icon), so duplicating the same launcher here as a
    // "Theme" jump-link section produced two paths into the same
    // surface. Rely on the topbar icon — leave the settings sidebar
    // for genuinely distinct surfaces (font, notifications, titlebar).

    // ── Custom title bar (Electron only) ────────────────────────────
    // Pinned to the top of the panel: it's the most disruptive
    // appearance toggle (window chrome reflows on flip) and users
    // hunting for it shouldn't need to scroll past every font row.
    if (spec.isElectron) {
        body.appendChild(buildToggleSection(
            title = "Custom title bar",
            currentValue = { spec.host.useCustomTitleBar },
            onPick = { v ->
                spec.host.setUseCustomTitleBar(v)
            },
        ))
    }

    // ── Shape and spacing ───────────────────────────────────────────
    // Above the font rows because they are the two coarsest controls in the
    // panel: they change what the shell *is* shaped like, where every row
    // below changes what it is lettered in. Both are user settings rather
    // than theme properties — see ThemeManagerHost.cornerRadiusPx.
    body.appendChild(buildPxChoiceSection(
        title = "Corner roundness",
        sizes = spec.cornerRadiusPresets,
        defaultSize = spec.appDefaultShape().cornerRadiusPx ?: DEFAULT_CORNER_RADIUS_PX,
        currentSize = { spec.host.cornerRadiusPx },
        onPick = { px ->
            spec.host.setCornerRadiusPx(px)
            applyCornerRadiusPx(px)
        },
    ))
    body.appendChild(buildSelectionStyleSection(
        currentValue = {
            spec.host.selectionStyle ?: spec.appDefaultShape().selectionStyle ?: SelectionStyle.Tint
        },
        onPick = { st ->
            spec.host.setSelectionStyle(st)
            applySelectionStyle(document.documentElement as HTMLElement, st)
        },
    ))
    body.appendChild(buildDensitySection(
        currentValue = {
            spec.host.uiDensity ?: spec.appDefaultShape().uiDensity ?: UiDensity.Compact
        },
        onPick = { d ->
            spec.host.setUiDensity(d)
            applyUiDensity(d)
        },
    ))

    // ── Sidebar font ────────────────────────────────────────────────
    body.appendChild(buildFontFaceSection(
        title = "Sidebar font",
        hint = "Used by the topbar and sidebars.",
        kind = FontKind.Proportional,
        showKinds = setOf(FontKind.Proportional, FontKind.Mono),
        currentKey = { spec.host.sidebarFontFamily },
        appDefaultKey = { spec.chromeDefaultKey() },
        onPick = { key ->
            spec.host.setSidebarFontFamily(key)
            applySidebarFontFamily(key)
        },
    ))
    body.appendChild(buildPxChoiceSection(
        title = "Sidebar size",
        sizes = spec.sidebarSizePresets,
        defaultSize = spec.sidebarSizeDefault,
        currentSize = { spec.host.sidebarFontSizePx },
        onPick = { px ->
            spec.host.setSidebarFontSizePx(px)
            applySidebarFontSizePx(px)
        },
    ))

    // ── Tab bar font ────────────────────────────────────────────────
    body.appendChild(buildFontFaceSection(
        title = "Tab bar font",
        hint = "Used by the tab strip (falls back to Sidebar when unset).",
        kind = FontKind.Proportional,
        showKinds = setOf(FontKind.Proportional, FontKind.Mono),
        currentKey = { spec.host.tabbarFontFamily },
        appDefaultKey = { spec.chromeDefaultKey() },
        onPick = { key ->
            spec.host.setTabbarFontFamily(key)
            applyTabbarFontFamily(key)
        },
    ))
    body.appendChild(buildPxChoiceSection(
        title = "Tab bar size",
        sizes = spec.sidebarSizePresets,
        defaultSize = spec.sidebarSizeDefault,
        currentSize = { spec.host.tabbarFontSizePx },
        onPick = { px ->
            spec.host.setTabbarFontSizePx(px)
            applyTabbarFontSizePx(px)
        },
    ))

    // ── Window title font ───────────────────────────────────────────
    body.appendChild(buildFontFaceSection(
        title = "Window title font",
        hint = "Used by each window's title bar (falls back to Sidebar when unset).",
        kind = FontKind.Proportional,
        showKinds = setOf(FontKind.Proportional, FontKind.Mono),
        currentKey = { spec.host.paneHeaderFontFamily },
        appDefaultKey = { spec.chromeDefaultKey() },
        onPick = { key ->
            spec.host.setPaneHeaderFontFamily(key)
            applyPaneHeaderFontFamily(key)
        },
    ))
    body.appendChild(buildPxChoiceSection(
        title = "Window title size",
        sizes = spec.sidebarSizePresets,
        defaultSize = spec.sidebarSizeDefault,
        currentSize = { spec.host.paneHeaderFontSizePx },
        onPick = { px ->
            spec.host.setPaneHeaderFontSizePx(px)
            applyPaneHeaderFontSizePx(px)
        },
    ))

    // ── Monospaced font (main content — terminals, code) ────────────
    body.appendChild(buildFontFaceSection(
        title = "Monospaced font",
        hint = "Used by terminals and code panes.",
        kind = FontKind.Mono,
        currentKey = { spec.host.monoFontFamily },
        onPick = { key ->
            spec.host.setMonoFontFamily(key)
            applyMonoFontFamily(key)
        },
    ))
    body.appendChild(buildPxChoiceSection(
        title = "Monospaced size",
        sizes = spec.mainSizePresets,
        defaultSize = spec.mainSizeDefault,
        currentSize = { spec.host.monoFontSizePx },
        onPick = { px ->
            spec.host.setMonoFontSizePx(px)
            applyMonoFontSizePx(px)
        },
    ))

    // ── Proportional font (main content — prose) ────────────────────
    body.appendChild(buildFontFaceSection(
        title = "Proportional font",
        hint = "Used by prose / note content.",
        kind = FontKind.Proportional,
        showKinds = setOf(FontKind.Proportional, FontKind.Mono),
        currentKey = { spec.host.proportionalFontFamily },
        appDefaultKey = { spec.proseDefaultKey() },
        onPick = { key ->
            spec.host.setProportionalFontFamily(key)
            applyProportionalFontFamily(key)
        },
    ))
    body.appendChild(buildPxChoiceSection(
        title = "Proportional size",
        sizes = spec.mainSizePresets,
        defaultSize = spec.mainSizeDefault,
        currentSize = { spec.host.proportionalFontSizePx },
        onPick = { px ->
            spec.host.setProportionalFontSizePx(px)
            applyProportionalFontSizePx(px)
        },
    ))

    // ── Display font (main content — headings) ──────────────────────
    body.appendChild(buildFontFaceSection(
        title = "Display font",
        hint = "Used by headings (falls back to Proportional when unset).",
        kind = FontKind.Proportional,
        showKinds = setOf(FontKind.Proportional, FontKind.Mono),
        currentKey = { spec.host.displayFontFamily },
        appDefaultKey = { spec.displayDefaultKey() },
        onPick = { key ->
            spec.host.setDisplayFontFamily(key)
            applyDisplayFontFamily(key)
        },
    ))
    body.appendChild(buildPxChoiceSection(
        title = "Display size",
        sizes = spec.mainSizePresets,
        defaultSize = spec.mainSizeDefault,
        currentSize = { spec.host.displayFontSizePx },
        onPick = { px ->
            spec.host.setDisplayFontSizePx(px)
            applyDisplayFontSizePx(px)
        },
    ))

    target.appendChild(panel)
}

/** Internal helper bundling a labelled section with its pill row container. */
private data class Section(val element: HTMLElement, val row: HTMLElement)

private fun makeSection(title: String, hint: String? = null): Section {
    val section = document.createElement("div") as HTMLElement
    section.className = "dt-settings-section"
    val label = document.createElement("div") as HTMLElement
    label.className = "dt-settings-label"
    label.textContent = title
    section.appendChild(label)
    if (hint != null) {
        val hintEl = document.createElement("div") as HTMLElement
        hintEl.className = "dt-settings-hint"
        hintEl.textContent = hint
        section.appendChild(hintEl)
    }
    val row = document.createElement("div") as HTMLElement
    row.className = "dt-settings-button-row"
    section.appendChild(row)
    return Section(section, row)
}

/**
 * Builds one font-face pill row.
 *
 * @param kind the section's primary kind. Drives the system default
 *   ([FontKind.Mono] → `system`, [FontKind.Proportional] → `systemProp`)
 *   and floats presets of this kind to the front of the row.
 * @param showKinds the kinds whose presets are offered in the row.
 *   Defaults to just [kind]. Proportional chrome sections (Sidebar / Tab
 *   bar / Proportional) pass both kinds so users can also pick a
 *   monospaced face for chrome — the proportional presets stay first,
 *   monospaced ones follow.
 * @param appDefaultKey the preset key the app applies to this surface when the
 *   user has picked none (e.g. a deployment brand font). When [currentKey] is
 *   null/empty the row highlights this key — falling back to the system default
 *   — so the ringed pill matches the font actually painted, not just the user's
 *   override. Returns null when the app has no default for the surface.
 */
private fun buildFontFaceSection(
    title: String,
    hint: String,
    kind: FontKind,
    currentKey: () -> String?,
    onPick: (String?) -> Unit,
    showKinds: Set<FontKind> = setOf(kind),
    appDefaultKey: () -> String? = { null },
): HTMLElement {
    val section = makeSection(title, hint)
    val row = section.row
    val installed = detectInstalledFonts()
    val current = currentKey()
    // System default first, regardless of order in [allFontPresets], so
    // users without a strong opinion always see a familiar label at the
    // start of the row. When the row offers more than one kind (e.g.
    // chrome sections that also list monospaced faces), presets matching
    // the section's primary [kind] are floated ahead of the rest while
    // preserving each group's declared order (sortedWith is stable).
    //
    // Iterates [allFontPresets] (built-ins + app-injected via
    // [registerFontPresets]) — not just the built-ins — so a deployment's
    // brand font appears as a pickable pill exactly like a built-in, matching
    // how every resolver already walks the merged list. detectInstalledFonts()
    // reports injected presets as always-available, so they pass the filter.
    val systemKey = if (kind == FontKind.Mono) "system" else "systemProp"
    // When the user has overridden nothing, the ringed pill is the app's default
    // for this surface (a brand font) if it has one, else the system default —
    // so the highlight tracks what is actually painted, not an empty override.
    val effectiveDefaultKey = appDefaultKey() ?: systemKey
    val sortedPresets = allFontPresets()
        .filter { it.kind in showKinds }
        .sortedWith(compareBy(
            { if (it.key == systemKey) 0 else 1 },
            { if (it.kind == kind) 0 else 1 },
        ))
    for (preset in sortedPresets) {
        if (preset.key !in installed) continue
        val isSelected = preset.key == current ||
            (current.isNullOrEmpty() && preset.key == effectiveDefaultKey)
        val btn = document.createElement("button") as HTMLElement
        btn.setAttribute("type", "button")
        btn.className = "dt-settings-choice-btn" + if (isSelected) " dt-selected" else ""
        btn.textContent = preset.displayName
        btn.style.fontFamily = preset.cssStack
        btn.addEventListener("click", {
            // Optimistic selection update. Hosts may persist the picked
            // value asynchronously (e.g. termtastic's `appVm.setX` runs
            // through `launch { … }`), in which case re-reading
            // `currentKey()` immediately after `onPick` returns the *old*
            // value — leaving the previous selection lit until the next
            // click. Updating the DOM directly here makes the click
            // visually take effect on the first click, regardless of how
            // the host backs the setter. */
            val rowChildren = row.children
            for (i in 0 until rowChildren.length) {
                (rowChildren.item(i) as? HTMLElement)?.classList?.remove("dt-selected")
            }
            btn.classList.add("dt-selected")
            onPick(preset.key)
        })
        row.appendChild(btn)
    }
    return section.element
}

/**
 * Builds one pixel-valued pill row — font sizes, and the corner-radius row.
 *
 * Mirrors [buildFontFaceSection]'s null-fallback behaviour: when the
 * host has no stored value yet ([currentSize] returns null), the pill
 * matching [defaultSize] gets `.dt-selected` so the row always shows
 * exactly one ringed entry — even on a fresh install. The actual
 * rendered value in that case comes from CSS defaults
 * (`.dt-app-frame { font-size: 13px }` for sidebar/tabbar,
 * `--dt-corner-radius`'s 18px fallback for roundness), so [defaultSize]
 * must be kept in step with those.
 *
 * @param title         section title shown above the row.
 * @param sizes         pill values, in render order.
 * @param defaultSize   value to highlight when [currentSize] is null.
 * @param currentSize   reader for the host's stored value; may be null
 *   when nothing explicit has been picked.
 * @param onPick        called with the clicked value; the click handler
 *   also performs an optimistic DOM update so async hosts don't leave
 *   the previous selection lit.
 */
private fun buildPxChoiceSection(
    title: String,
    sizes: List<Int>,
    defaultSize: Int,
    currentSize: () -> Int?,
    onPick: (Int) -> Unit,
): HTMLElement {
    val section = makeSection(title)
    val row = section.row
    row.classList.add("dt-settings-size-row")
    val current = currentSize()
    for (s in sizes) {
        val btn = document.createElement("button") as HTMLElement
        btn.setAttribute("type", "button")
        val isSelected = s == current || (current == null && s == defaultSize)
        btn.className = "dt-settings-choice-btn" + if (isSelected) " dt-selected" else ""
        btn.textContent = "${s}px"
        btn.addEventListener("click", {
            // Optimistic selection update — see [buildFontFaceSection]
            // for the rationale. Async host setters can leave a stale
            // re-render reading the pre-click value otherwise.
            val rowChildren = row.children
            for (i in 0 until rowChildren.length) {
                (rowChildren.item(i) as? HTMLElement)?.classList?.remove("dt-selected")
            }
            btn.classList.add("dt-selected")
            onPick(s)
        })
        row.appendChild(btn)
    }
    return section.element
}

/**
 * Builds the chrome-density pill row.
 *
 * Its own builder rather than a reuse of [buildToggleSection] because the
 * choices are named states, not On/Off, and rather than of [buildPxChoiceSection]
 * because the underlying values are not numbers the user should be reasoning
 * about — "Comfortable" is one decision, not the six paddings it sets.
 *
 * @param currentValue reader for the host's stored density (never null; the
 *   caller substitutes [UiDensity.Compact]).
 * @param onPick       called with the clicked density.
 */
private fun buildDensitySection(
    currentValue: () -> UiDensity,
    onPick: (UiDensity) -> Unit,
): HTMLElement {
    val section = makeSection("Spacing", "How much air the chrome puts around windows, tabs and rows.")
    val row = section.row
    val current = currentValue()
    for (density in UiDensity.entries) {
        val btn = document.createElement("button") as HTMLElement
        btn.setAttribute("type", "button")
        btn.className = "dt-settings-choice-btn" + if (density == current) " dt-selected" else ""
        btn.textContent = density.name
        btn.addEventListener("click", {
            // Optimistic selection update — see [buildFontFaceSection].
            val rowChildren = row.children
            for (i in 0 until rowChildren.length) {
                (rowChildren.item(i) as? HTMLElement)?.classList?.remove("dt-selected")
            }
            btn.classList.add("dt-selected")
            onPick(density)
        })
        row.appendChild(btn)
    }
    return section.element
}

/**
 * Builds the selection-style pill row.
 *
 * Labelled by what the user sees rather than by the enum: "Tinted" and
 * "Filled" describe the result, where "Tint"/"Fill" describe the mechanism.
 *
 * @param currentValue reader for the host's stored style (never null; the
 *   caller substitutes [SelectionStyle.Tint]).
 * @param onPick       called with the clicked style.
 */
private fun buildSelectionStyleSection(
    currentValue: () -> SelectionStyle,
    onPick: (SelectionStyle) -> Unit,
): HTMLElement {
    val section = makeSection(
        "Selection",
        "How the focused window, active tab and active sidebar row are marked.",
    )
    val row = section.row
    val current = currentValue()
    for ((label, value) in listOf(
        "Tinted" to SelectionStyle.Tint,
        "Filled" to SelectionStyle.Fill,
    )) {
        val btn = document.createElement("button") as HTMLElement
        btn.setAttribute("type", "button")
        btn.className = "dt-settings-choice-btn" + if (value == current) " dt-selected" else ""
        btn.textContent = label
        btn.addEventListener("click", {
            // Optimistic selection update — see [buildFontFaceSection].
            val rowChildren = row.children
            for (i in 0 until rowChildren.length) {
                (rowChildren.item(i) as? HTMLElement)?.classList?.remove("dt-selected")
            }
            btn.classList.add("dt-selected")
            onPick(value)
        })
        row.appendChild(btn)
    }
    return section.element
}

private fun buildToggleSection(
    title: String,
    currentValue: () -> Boolean,
    onPick: (Boolean) -> Unit,
): HTMLElement {
    val section = makeSection(title)
    val row = section.row
    val current = currentValue()
    for ((label, value) in listOf("On" to true, "Off" to false)) {
        val btn = document.createElement("button") as HTMLElement
        btn.setAttribute("type", "button")
        btn.className = "dt-settings-choice-btn" + if (value == current) " dt-selected" else ""
        btn.textContent = label
        btn.addEventListener("click", {
            // Optimistic selection update — see [buildFontFaceSection].
            val rowChildren = row.children
            for (i in 0 until rowChildren.length) {
                (rowChildren.item(i) as? HTMLElement)?.classList?.remove("dt-selected")
            }
            btn.classList.add("dt-selected")
            onPick(value)
        })
        row.appendChild(btn)
    }
    return section.element
}
